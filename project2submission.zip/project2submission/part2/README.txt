To run our files please type
make

Then type ./outmtsort

You will see the correct output.
