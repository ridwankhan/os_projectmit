Our answer for Part 1 a is in file Porject2part1.c
Our answer for Part 1 b is in file Porject2part1b.c
Our answer for Part 1 c is in file Porject2part1c.c

If you would like to use your own data, please name it "numbers.txt".
To run our files type 
make

Then type
./outParta
./outPartb
./outPartc

For part c you can enter CTRL-C, CTRL-\, or open another terminal and type "kill SIGTERM <pid of parent process>"
For examples of this please go to our report that was sumbitted on sakai. It has further details.
