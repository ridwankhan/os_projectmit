To run our programming problems first type:
make

Then to run problem 1 type:
./outProb1 <integer value>

To run problem 3 type:
./outProb3

To run problem 4 type:
./outProb4


